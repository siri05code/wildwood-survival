# Wildwood Survival — Android app project

This is a starter Android wrapper around the current Wildwood Survival HTML game. It opens the game full-screen in landscape orientation and keeps the game assets bundled locally.

## What is included
- `app/src/main/assets/index.html` — game itself
- Android WebView launcher activity
- Landscape orientation and immersive fullscreen
- GitHub Actions workflow that builds a test APK and an unsigned release AAB artifact

## Important status
This is a **source project**, not a compiled APK/AAB. It has not been built or tested on a physical Android device in this environment. The release AAB produced by the included workflow is not Play Store-ready until it is signed and all Play Console requirements are completed. The current game is a single-player prototype; online multiplayer is not implemented by this wrapper.

## Build using a cloud runner from your phone
1. Create a GitHub repository while signed into an account managed by your parent/guardian if that account will publish the game.
2. Upload the contents of this folder to the repository's `main` branch (keep `.github/workflows/android-build.yml`).
3. Open the repository's **Actions** tab and run **Build Wildwood Survival Android app** (or push a commit).
4. Open the completed workflow run and download the `wildwood-survival-builds` artifact.
5. Install the debug APK on your Android phone for testing. Android may ask you to allow installs from the browser or file manager you use.
6. For Play Store release, configure a proper release signing key securely and complete the current Play Console declarations/testing steps. Never share your signing key or passwords.

## Build locally
Requires Android SDK platform 36, JDK 17, and Gradle 8.11+ / compatible Android Gradle Plugin 8.10.1. From this directory run:

```sh
gradle assembleDebug bundleRelease
```

Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`
Release bundle output: `app/build/outputs/bundle/release/app-release.aab`
